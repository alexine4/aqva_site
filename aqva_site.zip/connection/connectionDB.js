const Sequelize = require('sequelize')

const nameDB = 'u390040323_aqvaSite'
exports.nameDB = nameDB

const loginDB = 'u390040323_Alexine4'
exports.loginDB = loginDB

const passwordDB = 'Alexandr0511'
exports.passwordDB = passwordDB

const typeDB = 'mysql'
exports.typeDB = typeDB

	const sequelize = new Sequelize(
		nameDB,
		loginDB,
		passwordDB,
		{	
			dialect: typeDB
		
		}
		
	)
	
exports.sequelize = sequelize

const jwt = 'jwt-key'
exports.jwt = jwt